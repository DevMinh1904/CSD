package com.fptuni.csd201.object;

public class Person {
    
    
}
