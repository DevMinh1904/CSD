class BookingList {
    Node head;

    public BookingList() {
        head = null;
    }

   
}
